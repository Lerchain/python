import sys
from pymongo import MongoClient

def get_rank(user_id):
    db = MongoClient('127.0.0.1',27017).shiyanlou
#    sl = len(sys.argv)
#    if sl != 2:
#        print('Parameter Error')
#        sys.exit(1)
#    userid = int(sys.argv[1])

    f_user = {}

    for user in db.contests.find():
        f_user.setdefault(user['user_id'],[0,0])
        f_user[user['user_id']][0] += user['score']
        f_user[user['user_id']][1] += user['submit_time']

    def comp(x,y):
        if x[1][0]>y[1][0]:
            return True
        elif x[1][0]<y[1][0]:
            return False
        else:
            if x[1][1]<y[1][1]:
                return True
            else:
                return False
#sorted(f_user,key = lambda x:(x[1][0],x[1][1])) 
#sorted(f_user,key = comp)

    List = []
    for key, value in f_user.items():
        List.append([key,value])

    ll = len(List)

    if user_id > ll:
        return [0,0,0]

    for j in range(ll):
        for i in range(0,len(List)-1):
            if comp(List[i],List[i+1])==False:    
                List[i],List[i+1] = List[i+1],List[i]

    flag = 0
    for i, l in enumerate(List,start = 1):
        if l[0] == user_id:
            flag = 1
#        print("({}, {}, {})".format(i,l[1][0],l[1][1]))
            return [i,l[1][0],l[1][1]]
#            print(res)


#    if flag == 0:
#        print([0,0,0])

if __name__ == '__main__':
    ls = len(sys.argv)
    if ls != 2:
        print("Parameter Error")
        sys.exit(1)
    user_id = int(sys.argv[1])
    userdata = get_rank(user_id)
    print(userdata)


