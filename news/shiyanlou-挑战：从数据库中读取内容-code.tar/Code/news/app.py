from flask import Flask,render_template,abort
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime 
import json
import os
import re
app = Flask(__name__)
app.config['TEMPLATES-AUTO-RELOAD']=True
app.config['SQLALCHEMY_DATABASE_URI']='mysql://root@localhost/Lcdb'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
db = SQLAlchemy(app)

class File(db.Model):
    __tablename__ = 'files'

    id = db.Column(db.Integer,primary_key=True)
    title = db.Column(db.String(80),nullable=False)
    created_time = db.Column(db.DateTime)
    category_id = db.Column(db.Integer,db.ForeignKey('Categories.id'))
    category = db.relationship('Category',uselist=False) 
    content = db.Column(db.Text)
    
    def __init__(self,title,created_time,category,content):
        self.title = title
        self.created_time = created_time
        self.category = category
        self.content = content

class Category(db.Model):
    __tablename__ = 'Categories'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80),nullable=False)
    files = db.relationship('File')
    
    def __init__(self, name):
        self.name = name

db.create_all()
java = Category('Java')
python = Category('Python')

file1 = File('Hello Java', datetime.utcnow(),java,'File Content- Java is cool!')
file2 = File('Hello Python', datetime.utcnow(),python,'File Content - Python is cool!')
db.session.add(java)
db.session.add(python)
db.session.add(file1)
db.session.add(file2)
db.session.commit()

@app.route('/')
def index():
#    filesname = os.listdir('/home/shiyanlou/files/')
#    filesname = re.findall('.*.json$' ,filesname)
#    titles = []
#    for filename in filesname:
#        if filename[-5:] != '.json':
#            continue
#        with open('/home/shiyanlou/files/{}'.format(filename)) as file:
#            data = json.load(file)
#            title = data['title']
#            titles.append(title)
    return render_template('index.html',files = File.query.all())

@app.route('/files/<int:file_id>')
def file(file_id):
#    filesname = os.listdir('/home/shiyanlou/files/')
#    filename += ".json"
#    if filename  not in filesname:
#        abort(404)
#    with open('/home/shiyanlou/files/{}'.format(filename)) as file:
#        data = json.load(file)
#        content = data['content']
    file_item = File.query.get_or_404(file_id)
    return render_template('file.html',file_item = file_item)

@app.errorhandler(FileNotFoundError)
#@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'),404

